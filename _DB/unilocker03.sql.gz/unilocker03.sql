-- MySQL dump 10.13  Distrib 5.6.36, for Linux (x86_64)
--
-- Host: localhost    Database: unilocker03
-- ------------------------------------------------------
-- Server version	5.6.36-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_estatus`
--

DROP TABLE IF EXISTS `tbl_estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_estatus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_estatus`
--

LOCK TABLES `tbl_estatus` WRITE;
/*!40000 ALTER TABLE `tbl_estatus` DISABLE KEYS */;
INSERT INTO `tbl_estatus` (`id`, `Estado`) VALUES (1,'Ocupado'),(2,'Libre'),(3,'Apartado'),(4,'Renovar'),(5,'Cancelar');
/*!40000 ALTER TABLE `tbl_estatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_locker`
--

DROP TABLE IF EXISTS `tbl_locker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_locker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Numero` varchar(20) NOT NULL,
  `Precio` float NOT NULL,
  `idEstatus` int(10) unsigned NOT NULL,
  `idSeccion` int(10) unsigned NOT NULL,
  `idUsuario` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `locker_idfk_estatus` (`idEstatus`),
  KEY `locker_idfk_seccion` (`idSeccion`),
  KEY `locker_idfk_usuario` (`idUsuario`),
  CONSTRAINT `locker_idfk_estatus` FOREIGN KEY (`idEstatus`) REFERENCES `tbl_estatus` (`id`),
  CONSTRAINT `locker_idfk_seccion` FOREIGN KEY (`idSeccion`) REFERENCES `tbl_seccion` (`id`),
  CONSTRAINT `locker_idfk_usuario` FOREIGN KEY (`idUsuario`) REFERENCES `tbl_usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_locker`
--

LOCK TABLES `tbl_locker` WRITE;
/*!40000 ALTER TABLE `tbl_locker` DISABLE KEYS */;
INSERT INTO `tbl_locker` (`id`, `Numero`, `Precio`, `idEstatus`, `idSeccion`, `idUsuario`) VALUES (2,'1110',20,2,1,2),(3,'1120',20,2,1,2),(4,'1210',40,2,1,2),(5,'1220',40,2,1,2),(6,'1310',60,1,1,55),(7,'1320',60,2,1,2),(8,'1410',80,2,1,2),(9,'1420',80,2,1,2),(10,'2110',20,2,2,2),(11,'2120',20,2,2,2),(12,'2210',40,2,2,2),(13,'2220',40,2,2,2),(14,'2310',60,3,2,54),(15,'2320',60,1,2,56),(16,'2410',80,2,2,2),(17,'2420',80,2,2,2);
/*!40000 ALTER TABLE `tbl_locker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_renta`
--

DROP TABLE IF EXISTS `tbl_renta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_renta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idLocker` int(10) unsigned NOT NULL,
  `idUsuario` int(10) unsigned NOT NULL,
  `idRentador` int(10) unsigned NOT NULL,
  `Comentarios` varchar(200) DEFAULT NULL,
  `Concepto` enum('Rentar','Renovar','Apartar','Cancelar','Rentado','Renovado','Cancelado') DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `renta_idfk_locker` (`idLocker`),
  KEY `renta_idfk_usuario` (`idUsuario`),
  KEY `renta_idfk_rentador` (`idRentador`),
  CONSTRAINT `renta_idfk_rentador` FOREIGN KEY (`idRentador`) REFERENCES `tbl_usuarios` (`id`),
  CONSTRAINT `renta_idfk_seccion` FOREIGN KEY (`idLocker`) REFERENCES `tbl_locker` (`id`),
  CONSTRAINT `renta_idfk_usuario` FOREIGN KEY (`idUsuario`) REFERENCES `tbl_usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_renta`
--

LOCK TABLES `tbl_renta` WRITE;
/*!40000 ALTER TABLE `tbl_renta` DISABLE KEYS */;
INSERT INTO `tbl_renta` (`id`, `idLocker`, `idUsuario`, `idRentador`, `Comentarios`, `Concepto`, `Fecha`) VALUES (10,2,40,52,'-','Rentado','2017-12-06'),(11,3,51,52,'-','Rentado','2017-12-06'),(12,3,51,52,'-','Cancelado','2017-12-06'),(13,15,56,52,'se rento','Rentado','2017-12-06'),(14,14,54,2,'-','Apartar','2017-12-06'),(15,6,55,52,'-','Rentado','2017-12-06'),(16,2,40,52,'No pago','Cancelado','2017-12-06');
/*!40000 ALTER TABLE `tbl_renta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_seccion`
--

DROP TABLE IF EXISTS `tbl_seccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_seccion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_seccion`
--

LOCK TABLES `tbl_seccion` WRITE;
/*!40000 ALTER TABLE `tbl_seccion` DISABLE KEYS */;
INSERT INTO `tbl_seccion` (`id`, `Nombre`) VALUES (1,'Piso 1'),(2,'Piso 2'),(3,'Deportivo');
/*!40000 ALTER TABLE `tbl_seccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tipo`
--

DROP TABLE IF EXISTS `tbl_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tipo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tipo`
--

LOCK TABLES `tbl_tipo` WRITE;
/*!40000 ALTER TABLE `tbl_tipo` DISABLE KEYS */;
INSERT INTO `tbl_tipo` (`id`, `Nombre`) VALUES (1,'Administrador'),(2,'Usuario');
/*!40000 ALTER TABLE `tbl_tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_usuarios`
--

DROP TABLE IF EXISTS `tbl_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `Matricula` varchar(10) NOT NULL,
  `Correo` varchar(60) DEFAULT NULL,
  `idTipo` int(11) unsigned NOT NULL,
  `Contra` varchar(255) NOT NULL,
  `Foto` varchar(255) DEFAULT 'imgs_profile/default.png',
  `Activo` int(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `usuarios_idfk_tipo` (`idTipo`),
  CONSTRAINT `usuarios_idfk_tipo` FOREIGN KEY (`idTipo`) REFERENCES `tbl_tipo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_usuarios`
--

LOCK TABLES `tbl_usuarios` WRITE;
/*!40000 ALTER TABLE `tbl_usuarios` DISABLE KEYS */;
INSERT INTO `tbl_usuarios` (`id`, `Nombres`, `Apellidos`, `Matricula`, `Correo`, `idTipo`, `Contra`, `Foto`, `Activo`) VALUES (2,'Admin','Admin','-','notificaciones@unilocker.com.mx',1,'4a7d1ed414474e4033ac29ccb8653d9b','imgs_profile/default.png',1),(40,'Natalie','Conde','1589902','bstaru95@gmail.com',2,'4a7d1ed414474e4033ac29ccb8653d9b','imgs_profile/1512413063tumblr_oty1rj2rGE1vq223bo1_1280.png',1),(51,'victor','garcia','1549647','victor.garvzz11@gmail.com',2,'827ccb0eea8a706c4c34a16891f84e7b','imgs_profile/1512485686CfUrtVLWAAAKCmP.jpg',1),(52,'Administrador','admin','0000000','admin@gmail.com',1,'21232f297a57a5a743894a0e4a801fc3','imgs_profile/1512605970received_1540430986012929.jpeg',3),(54,'Jose Angel','Osorio','1694074','pelonlocosoy@gmail.com',2,'81dc9bdb52d04dc20036dbd8313ed055','imgs_profile/1512596745al chile.jpg',1),(55,'Juan ','Bautista','1201448','juan@gmail.com',2,'81dc9bdb52d04dc20036dbd8313ed055','imgs_profile/default.png',1),(56,'Aimee','Chavez','1513976','iliana.aimee@gmail.com',2,'e99a18c428cb38d5f260853678922e03','imgs_profile/1512605734tumblr_osbpksGxqQ1vuand5o4_250.png',1),(57,'Tomas Eduardo','Ibarra Hernandez','1519737','tomas.ibhz@gmail.com',1,'d68a18275455ae3eaa2c291eebb46e6d','imgs_profile/1512605913foOOL.png',1);
/*!40000 ALTER TABLE `tbl_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'unilocker03'
--

--
-- Dumping routines for database 'unilocker03'
--
/*!50003 DROP PROCEDURE IF EXISTS `i_RentaByAdmin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `i_RentaByAdmin`(
	IN idLock int,
    IN idUser int,
    IN idRent int,
    IN coments varchar(200),
    IN dia date
)
BEGIN
	SET @consulta = (SELECT EXISTS(SELECT idUsuario FROM tbl_locker WHERE idUsuario = idUser));
    
	IF(@consulta != 1) THEN
		INSERT INTO tbl_renta (idLocker, idUsuario, idRentador,Comentarios,Concepto,Fecha)
		VALUES (idLock,idUser,idRent,coments,'Rentado',dia);
        
        UPDATE tbl_locker
        SET idEstatus = 1, idUsuario = idUser
        WHERE id = idLock;
        
		SELECT 'Se guard�';
	ELSE
		SELECT 'El usuario ya cuenta con un locker';
	END IF;
		
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `i_RentaByUsuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `i_RentaByUsuario`(
	IN idLock int,
    IN idUser int,
    IN dia date
)
BEGIN
	SET @consulta = (SELECT EXISTS(SELECT idUsuario FROM tbl_locker WHERE idUsuario = idUser));

	IF(@consulta != 1) THEN
		INSERT INTO tbl_renta (idLocker, idUsuario, idRentador,Comentarios,Concepto,Fecha)
		VALUES (idLock,idUser,2,'-','Apartar',dia);
        
        UPDATE tbl_locker
        SET idEstatus = 3, idUsuario = idUser
        WHERE id = idLock;
        
        SELECT 'Se guard�';
	ELSE
		SELECT 'Ya cuentas con un locker';
	END IF;

		
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `i_usuario_adm` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `i_usuario_adm`(IN `uname` VARCHAR(50), IN `ulast` VARCHAR(50), IN `mat` VARCHAR(10), IN `mail` VARCHAR(30), IN `pass` VARCHAR(255))
BEGIN
		INSERT INTO tbl_usuarios (Nombres, Apellidos, Matricula,Correo,idTipo,Contra,Activo)
		VALUES (uname,ulast,mat,mail,1,MD5(pass),1);
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `i_usuario_reg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `i_usuario_reg`(
	IN uname varchar(50),
    IN ulast varchar(50),
    IN mat varchar(10),
    IN mail varchar(30),
    IN pass varchar(255)
)
BEGIN
		INSERT INTO tbl_usuarios (Nombres, Apellidos, Matricula,Correo,idTipo,Contra,Activo)
		VALUES (uname,ulast,mat,mail,2,MD5(pass),3);
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_DataImprimir` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_DataImprimir`(IN `idUsuario` INT, IN `idLocker` INT, IN `concepto` VARCHAR(20))
BEGIN
	SELECT R.Fecha, R.id as Folio,  U.id, U.Nombres, U.Apellidos, U.Matricula, L.Numero, L.Precio, R.Concepto, E.Estado as EstadoLocker

	FROM tbl_renta R
	INNER JOIN tbl_locker L
	ON L.id = R.idLocker
	INNER JOIN tbl_usuarios U
	ON U.id = R.idUsuario
	INNER JOIN tbl_estatus E
	ON E.id = L.idEstatus

	 WHERE 	R.idUsuario = idUsuario AND
			R.idLocker = idLocker AND
			(
				(concepto = 'Rentar' AND R.Concepto = 'Rentar') OR
                (concepto = 'Rentar' AND R.Concepto = 'Rentado') OR
				(concepto = 'Renovar' AND R.Concepto = 'Renovar' ) OR
                (concepto = 'Renovar' AND R.Concepto = 'Renovado' ) OR
				(concepto = 'Apartar' AND R.Concepto = 'Apartar' ) OR
                (concepto = 'Apartar' AND R.Concepto = 'Apartado' ) OR
				(concepto = 'Cancelar' AND R.Concepto = 'Cancelar') OR
                (concepto = 'Cancelar' AND R.Concepto = 'Cancelado')
			)
	ORDER BY R.id DESC
    LIMIT 1;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_Locker` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_Locker`(  
)
BEGIN
	SELECT id,Numero, Precio, idEstatus, idSeccion, idUsuario 
    FROM tbl_locker
    where idEstatus = 2;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_LockerBySeccion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_LockerBySeccion`(  
IN idSec int
)
BEGIN
	SELECT id,Numero, Precio, idEstatus, idSeccion, idUsuario 
    FROM tbl_locker
    WHERE idSec = idSeccion  AND idEstatus = 2;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_LockerByUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_LockerByUser`(     
    IN idUser int
)
BEGIN

	SELECT id, Numero,Precio, idEstatus, idSeccion, idUsuario

	FROM tbl_locker

	WHERE idUsuario = idUser; 
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_LockerByUserOcupado` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_LockerByUserOcupado`(     
   IN idU int, 
   IN idSec int
)
BEGIN
	SELECT id,Numero, Precio, idEstatus, idSeccion, idUsuario 
    FROM tbl_locker
    WHERE  idSec = idSeccion AND idU = idUsuario  AND idEstatus = 1;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_login`(
    IN corr varchar (60),IN pass varchar(255)
)
BEGIN
		SELECT U.id, U.Nombres, U.Apellidos, U.Matricula, U.Correo, U.idTipo, U.Contra, U.Foto, 
        ifnull( (SELECT L.Numero FROM tbl_locker L WHERE L.idUsuario = U.id ), 'Sin Locker') as Locker,
        U.Activo
		FROM tbl_usuarios U
		WHERE Contra = MD5(pass) AND Correo = corr AND  Activo != 0;
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_Pendientes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_Pendientes`()
BEGIN
	SELECT distinct
		 R.id as FOLIO, R.Fecha, R.Concepto, L.Numero, L.Precio, U.Nombres AS Usuario, U.id as idU

	FROM tbl_locker L
	INNER JOIN tbl_renta R
	ON R.idLocker = L.id
	INNER JOIN tbl_estatus E
	ON L.idEstatus = E.id
	INNER JOIN tbl_usuarios U
	ON L.idUsuario = U.id

	 WHERE  (E.id = 3 AND R.Concepto = 'Apartar') OR 
			(E.id = 3 AND R.Concepto = 'Renovar') OR 
			(E.id = 5 AND R.Concepto = 'Cancelar')
	
    ORDER BY R.Fecha DESC;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_ReporteLockers_Tipo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_ReporteLockers_Tipo`(
    in concepto int
)
BEGIN
	SELECT distinct
			-- R.id as FOLIO, R.Fecha,
		 L.Numero, L.Precio, E.Estado, U.Nombres AS Usuario

	FROM tbl_locker L
	INNER JOIN tbl_estatus E
	ON L.idEstatus = E.id
	INNER JOIN tbl_usuarios U
	ON L.idUsuario = U.id

	 WHERE 
			(concepto = 0 ) OR
			(concepto = 1 AND E.id = 1 ) OR
			(concepto = 2 AND E.id = 3 ) OR
			(concepto = 3 AND E.id = 2 );
			
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_Resumen` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_Resumen`()
BEGIN
	select R.id as Folio,  U.Nombres, L.Numero,R.Concepto, E.Estado, R.Fecha

	from tbl_locker L
	inner join tbl_renta R 
	on L.id = R.idLocker
	inner join tbl_estatus E
	on E.id = L.idEstatus
	inner join tbl_usuarios U 
	on U.id = L.idUsuario

	order by R.id desc
    LIMIT 7;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_Seccion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_Seccion`(  
)
BEGIN
	SELECT id,Nombre 
    FROM tbl_seccion;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_todoUsuarios` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_todoUsuarios`()
BEGIN
	SELECT U.id,U.Foto,U.Nombres as Nombre,U.Matricula,U.Correo,U.Activo, T.Nombre as Tipo
	FROM tbl_usuarios U
    INNER JOIN tbl_tipo T
    ON U.idTipo = T.id
WHERE U.id != 2;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_usuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_usuario`()
BEGIN
		SELECT id,Matricula
		FROM tbl_usuarios
        WHERE Activo = 1 AND id != 2;
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_UsuariosNoAdmin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_UsuariosNoAdmin`(
)
BEGIN
	SELECT U.id,U.Foto,CONCAT(U.Nombres,' ',U.Apellidos) as Nombre,U.Matricula,U.Correo,U.Activo, T.Nombre as Tipo
	FROM tbl_usuarios U
    INNER JOIN tbl_tipo T
    ON U.idTipo = T.id
	WHERE Activo = 1 AND T.id = 2;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `s_usuarioUpdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `s_usuarioUpdate`(
	IN idu int
)
BEGIN
		SELECT U.id, U.Nombres, U.Apellidos, U.Matricula, U.Correo, U.idTipo, U.Contra, U.Foto, 
        ifnull( (SELECT L.Numero FROM tbl_locker L WHERE L.idUsuario = U.id ), 'Sin Locker') as Locker
		FROM tbl_usuarios U
        WHERE U.id = idu AND U.Activo = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_Aceptar` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_Aceptar`(IN `elocker` INT, IN `id_Renta` INT, IN `idRent` INT, IN `coments` VARCHAR(200), IN `idUser` INT, IN `hoy` DATE, IN `tipo` VARCHAR(20))
BEGIN
	UPDATE	tbl_renta
	SET idRentador = idRent, Comentarios = coments, Fecha = hoy, Concepto = tipo
	WHERE id = id_Renta;
	
	UPDATE tbl_locker
	SET idEstatus = 1
	WHERE  idUsuario = idUser;	
        
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_CambiarTipo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_CambiarTipo`(
	IN idu int
)
BEGIN
	UPDATE tbl_usuarios
    SET idTipo = 1
	WHERE id = idu;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_CambiarTipoUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_CambiarTipoUser`(
	IN idu int
)
BEGIN
	
	UPDATE tbl_usuarios
    SET idTipo = 2
	WHERE id = idu;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_CancelarByAdmin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_CancelarByAdmin`(
	IN idLock int,
    IN idUser int,
    IN idRent int,
    IN coments varchar(200),
    IN dia date
)
BEGIN
		INSERT INTO tbl_renta (idLocker, idUsuario, idRentador,Comentarios,Concepto,Fecha)
		VALUES (idLock,idUser,idRent,coments,'Cancelado',dia);
        
        UPDATE tbl_locker
        SET idEstatus = 2, idUsuario = 2
        WHERE id = idLock;
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_CancelarByUsuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_CancelarByUsuario`(
	IN idLock int,    
	IN idUser int,
	IN dia date
)
BEGIN
		INSERT INTO tbl_renta (idLocker, idUsuario, idRentador,Comentarios,Concepto,Fecha)
		VALUES (idLock,idUser,2,'-','Cancelar',dia);
        
        UPDATE tbl_locker
        SET idEstatus = 5, idUsuario = idUser
        WHERE id = idLock;
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_Contra` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_Contra`(
	IN idu int,
    IN pss varchar(255)
)
BEGIN
	UPDATE tbl_usuarios
     SET Contra = MD5(pss)
    WHERE id = idu;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_Foto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_Foto`(
	IN idu int,
    IN foto varchar(255)
    )
BEGIN
	UPDATE tbl_usuarios
    SET Foto = foto
    WHERE id = idu;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_FotoUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_FotoUser`(
	IN idu int,
    in foton varchar(255)
)
BEGIN
	UPDATE tbl_usuarios
    SET Foto = foton
	WHERE id = idu;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_Liberar` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_Liberar`(
	IN elocker int,
	IN id_Renta int,    
    IN idRent int,
    IN coments varchar(200),    
    IN idUser int,
    IN hoy date,
    IN tipo varchar(20)
)
BEGIN
	UPDATE	tbl_renta
	SET idRentador = idRent, Comentarios = coments, Fecha = hoy, Concepto = tipo
	WHERE id = id_Renta;

	UPDATE tbl_locker
	SET idEstatus = 2, idUsuario = 2
	WHERE  idUsuario = idUser;	      
        
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_RenovarByAdmin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_RenovarByAdmin`(
    IN idLock int,
    IN idUser int,
    IN idRent int,
    IN coments varchar(200),
    IN dia date
)
BEGIN
		INSERT INTO tbl_renta (idLocker, idUsuario, idRentador,Comentarios,Concepto,Fecha)
		VALUES (idLock,idUser,idRent,coments,'Renovado',dia);
        
        UPDATE tbl_locker
        SET idEstatus = 1, idUsuario = idUser
        WHERE id = idLock;

	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_RenovarByUsuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_RenovarByUsuario`(  
    IN idLock int,    
    IN idUser int,
    IN dia date
)
BEGIN
		INSERT INTO tbl_renta (idLocker, idUsuario, idRentador,Comentarios,Concepto,Fecha)
		VALUES (idLock,idUser,2,'-','Renovar',dia);
        
        UPDATE tbl_locker
        SET idEstatus = 3, idUsuario = idUser
        WHERE id = idLock;
        
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_Usuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_Usuario`(
	IN idu int,
	IN nombres varchar(50),
    IN apellid varchar(50),
    IN matricu varchar(10),
    IN correo varchar(60)
)
BEGIN
	UPDATE tbl_usuarios
    SET Nombres = nombres, Apellidos = apellid, Matricula=matricu, Correo=correo
    WHERE id = idu;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_VerificarUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_VerificarUser`(
	IN correo varchar(50)
)
BEGIN
	UPDATE tbl_usuarios
    SET Activo = 2
	WHERE Correo = correo;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `u_WalkT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`bstaru95`@`localhost` PROCEDURE `u_WalkT`(
	IN idd int
)
BEGIN
	UPDATE tbl_usuarios
    SET Activo = 1
	WHERE id = idd;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-10 20:14:59
